package com.quiz.aiquizgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AIquizgameApplicationTests {

    @Test
    void contextLoads() {
    }

}
