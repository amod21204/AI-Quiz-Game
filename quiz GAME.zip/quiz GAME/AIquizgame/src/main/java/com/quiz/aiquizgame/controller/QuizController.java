package com.quiz.aiquizgame.controller;

import com.quiz.aiquizgame.dto.QuizRequest;
import com.quiz.aiquizgame.model.Question;
import com.quiz.aiquizgame.service.QuizService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class QuizController {

    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    @PostMapping("/quiz")
    public List<Question> generateQuiz(@RequestBody QuizRequest request) {

        System.out.println("Topic: " + request.getTopic());
        System.out.println("Difficulty: " + request.getDifficulty());
        System.out.println("Questions: " + request.getNumberOfQuestions());

        return quizService.generateQuiz(
                request.getTopic(),
                request.getDifficulty(),
                request.getNumberOfQuestions()
        );
    }
}