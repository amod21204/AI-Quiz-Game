package com.quiz.aiquizgame.dto;

public class QuizRequest {

    private String topic;
    private String difficulty;
    private int numberOfQuestions;

    public QuizRequest() {
    }

    public QuizRequest(String topic, String difficulty, int numberOfQuestions) {
        this.topic = topic;
        this.difficulty = difficulty;
        this.numberOfQuestions = numberOfQuestions;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public int getNumberOfQuestions() {
        return numberOfQuestions;
    }

    public void setNumberOfQuestions(int numberOfQuestions) {
        this.numberOfQuestions = numberOfQuestions;
    }
}