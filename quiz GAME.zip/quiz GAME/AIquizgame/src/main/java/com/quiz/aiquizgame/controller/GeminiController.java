package com.quiz.aiquizgame.controller;

import com.quiz.aiquizgame.service.GeminiService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GeminiController {

    private final GeminiService geminiService;

    public GeminiController(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    @GetMapping("/ai")
    public String testAI() {

        return geminiService.generateQuiz(
                "Java",
                "Easy",
                3
        ).toString();

    }
}