package com.quiz.aiquizgame.service;

import com.quiz.aiquizgame.model.Question;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizService {

    private final GeminiService geminiService;

    public QuizService(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    public List<Question> generateQuiz(String topic,
                                       String difficulty,
                                       int numberOfQuestions) {

        return geminiService.generateQuiz(
                topic,
                difficulty,
                numberOfQuestions
        );
    }
}