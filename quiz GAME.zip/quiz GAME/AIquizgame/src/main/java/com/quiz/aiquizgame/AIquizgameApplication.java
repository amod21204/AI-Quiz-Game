package com.quiz.aiquizgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AIquizgameApplication {

    public static void main(String[] args) {
        SpringApplication.run(AIquizgameApplication.class, args);
    }

}
