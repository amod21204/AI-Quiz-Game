package com.quiz.aiquizgame.service;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.quiz.aiquizgame.model.Question;
import java.util.List;
@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final WebClient webClient;

    public GeminiService(WebClient webClient) {
        this.webClient = webClient;
    }

    public List<Question> generateQuiz(String topic,
                                       String difficulty,
                                       int count) {

        String prompt = """
Generate %d multiple choice questions on the topic "%s".

Difficulty: %s.

Return ONLY a valid JSON array.

Do NOT write any explanation.
Do NOT use markdown.
Do NOT use ```json.
Do NOT write anything before or after the JSON.

Format:

[
  {
    "question":"...",
    "options":[
      "...",
      "...",
      "...",
      "..."
    ],
    "answer":"..."
  }
]
""".formatted(count, topic, difficulty);

        String body = """
                {
                  "contents": [{
                    "parts": [{
                      "text": "%s"
                    }]
                  }]
                }
                """.formatted(prompt.replace("\"", "\\\""));

        String response = webClient.post()
                .uri("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(String.class)
                .block();

        try {

            JsonNode root = objectMapper.readTree(response);

            String text = root
                    .path("candidates")
                    .get(0)
                    .path("content")
                    .path("parts")
                    .get(0)
                    .path("text")
                    .asText();

            // Remove markdown if Gemini returns ```json
            text = text.replace("```json", "")
                    .replace("```", "")
                    .trim();

            return objectMapper.readValue(
                    text,
                    objectMapper.getTypeFactory()
                            .constructCollectionType(List.class, Question.class)
            );

        } catch (Exception e) {

            e.printStackTrace();

            return List.of();

        }
        }
    }
