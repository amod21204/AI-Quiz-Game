let questions = [];

// Generate Quiz
async function loadQuiz() {

    const topic = document.getElementById("topic").value;
    const difficulty = document.getElementById("difficulty").value;
    const count = parseInt(document.getElementById("count").value);

    if (!topic || !difficulty || isNaN(count) || count <= 0) {
        alert("Please fill all fields correctly.");
        return;
    }

    try {

        const response = await fetch("http://localhost:8080/quiz", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                topic: topic,
                difficulty: difficulty,
                numberOfQuestions: count

            })

        });

        if (!response.ok) {
            throw new Error("Server Error : " + response.status);
        }

        questions = await response.json();

        displayQuiz();

    } catch (error) {

        console.error(error);

        alert("Failed to generate quiz.");

    }

}

// Display Quiz
function displayQuiz() {

    const quizContainer = document.getElementById("quizContainer");

    quizContainer.innerHTML = "";

    questions.forEach((q, index) => {

        let html = `
            <div class="question">

                <h3>Q${index + 1}. ${q.question}</h3>
        `;

        q.options.forEach(option => {

            html += `
                <label>

                    <input
                        type="radio"
                        name="question${index}"
                        value="${option}">

                    ${option}

                </label>

                <br>
            `;

        });

        html += `
            </div>
            <br>
        `;

        quizContainer.innerHTML += html;

    });

    quizContainer.innerHTML += `
        <button onclick="submitQuiz()">
            Submit Quiz
        </button>
    `;

}

// Submit Quiz
function submitQuiz() {

    let score = 0;

    questions.forEach((q, index) => {

        const selected = document.querySelector(
            `input[name="question${index}"]:checked`
        );

        if (selected && selected.value === q.answer) {

            score++;

        }

    });

    const percentage = ((score / questions.length) * 100).toFixed(2);

    document.getElementById("result").innerHTML = `
        <h2>Quiz Completed!</h2>

        <h3>Your Score: ${score} / ${questions.length}</h3>

        <h3>Percentage: ${percentage}%</h3>
    `;

}